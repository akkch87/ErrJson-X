package com.errjson.x;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Палитра и фабрики элементов интерфейса. Интерфейс строится кодом, без XML-разметки. */
public final class Ui {

    public static final int BG = 0xFF0B0B12;
    public static final int CARD = 0xFF171725;
    public static final int TEXT = 0xFFF4F4FF;
    public static final int CYAN = 0xFF00E5FF;
    public static final int PURPLE = 0xFFA855F7;
    public static final int MUTED = 0xFF8D8DA8;
    public static final int STROKE = 0xFF26263A;
    public static final int DANGER = 0xFFFF5470;
    public static final int SUCCESS = 0xFF22C55E;

    private Ui() {
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    /** Текст с учётом пользовательского масштаба. size задаётся в sp. */
    public static TextView text(Context c, CharSequence s, float size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size * Prefs.getTextScale(c));
        t.setTextColor(color);
        t.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return t;
    }

    public static TextView mono(Context c, CharSequence s, float size, int color, boolean bold) {
        TextView t = text(c, s, size, color, bold);
        t.setTypeface(bold ? Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) : Typeface.MONOSPACE);
        return t;
    }

    public static TextView sectionLabel(Context c, String s) {
        TextView t = mono(c, s.toUpperCase(Locale.ROOT), 11, MUTED, true);
        t.setLetterSpacing(0.12f);
        return t;
    }

    public static GradientDrawable rounded(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) {
            g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        }
        return g;
    }

    /** Скруглённый фон с эффектом нажатия. */
    public static Drawable ripple(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable content = rounded(c, fill, radiusDp, stroke, strokeDp);
        GradientDrawable mask = rounded(c, Color.WHITE, radiusDp, 0, 0);
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, mask);
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(rounded(c, CARD, 16, STROKE, 1));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static View spacer(Context c, int heightDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, heightDp)));
        return v;
    }

    /** Кнопка. filled = залитая цветом, иначе контурная. */
    public static TextView button(Context c, String label, int color, boolean filled) {
        TextView b = text(c, label, 14, filled ? BG : color, true);
        b.setGravity(Gravity.CENTER);
        int ph = dp(c, 18);
        int pv = dp(c, 12);
        b.setPadding(ph, pv, ph, pv);
        b.setMinHeight(dp(c, 44));
        b.setBackground(filled ? ripple(c, color, 12, 0, 0) : ripple(c, CARD, 12, color, 1));
        b.setClickable(true);
        b.setFocusable(true);
        pressable(b);
        return b;
    }

    public static EditText input(Context c, String hint, boolean multiline) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15 * Prefs.getTextScale(c));
        e.setBackground(rounded(c, BG, 12, STROKE, 1));
        int p = dp(c, 12);
        e.setPadding(p, p, p, p);
        e.setHighlightColor(withAlpha(Prefs.getAccent(c), 0x55));
        if (multiline) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setGravity(Gravity.TOP | Gravity.START);
        } else {
            e.setSingleLine(true);
        }
        return e;
    }

    /** Строка «подпись — значение». */
    public static LinearLayout infoRow(Context c, String label, String value) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(c, 4), 0, dp(c, 4));
        TextView l = mono(c, label, 11, MUTED, false);
        TextView v = mono(c, value, 12, TEXT, false);
        v.setGravity(Gravity.END);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(c, 12);
        row.addView(l, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(v, lp);
        return row;
    }

    /** Верхняя панель с кнопкой «назад» и заголовком. */
    public static LinearLayout topBar(final Activity a, String title) {
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = text(a, "←", 20, Prefs.getAccent(a), true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(ripple(a, CARD, 12, STROKE, 1));
        back.setClickable(true);
        back.setFocusable(true);
        back.setContentDescription("Назад");
        back.setOnClickListener(v -> a.finish());
        pressable(back);
        bar.addView(back, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 44)));

        TextView t = text(a, title, 20, TEXT, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(a, 14);
        bar.addView(t, lp);
        return bar;
    }

    /** Лёгкое уменьшение при нажатии. Не мешает обычному onClick. */
    @SuppressLint("ClickableViewAccessibility")
    public static void pressable(View v) {
        v.setOnTouchListener((view, e) -> {
            if (!Prefs.animationsEnabled(view.getContext())) {
                return false;
            }
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            }
            return false;
        });
    }

    /** Плавное появление. Если анимации выключены, ничего не делает. */
    public static void fadeIn(View v, long delayMs) {
        if (!Prefs.animationsEnabled(v.getContext())) {
            return;
        }
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 14));
        v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(delayMs)
                .setDuration(320)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    public static String formatSize(long bytes) {
        if (bytes < 0) {
            return "—";
        }
        if (bytes < 1024) {
            return bytes + " B";
        }
        double kb = bytes / 1024.0;
        if (kb < 1024) {
            return String.format(Locale.US, "%.1f KB", kb);
        }
        double mb = kb / 1024.0;
        if (mb < 1024) {
            return String.format(Locale.US, "%.1f MB", mb);
        }
        return String.format(Locale.US, "%.2f GB", mb / 1024.0);
    }
}
