package com.errjson.x;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Логотип: скруглённый квадрат со стилизованной буквой X. Рисуется кодом, без картинок. */
public class LogoView extends View {

    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint accentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint purplePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    public LogoView(Context context) {
        super(context);
        init(context);
    }

    public LogoView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context c) {
        int accent = Prefs.getAccent(c);

        bgPaint.setStyle(Paint.Style.FILL);
        bgPaint.setColor(Ui.CARD);

        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(Ui.withAlpha(accent, 0xAA));

        accentPaint.setStyle(Paint.Style.STROKE);
        accentPaint.setStrokeCap(Paint.Cap.ROUND);
        accentPaint.setColor(accent);

        purplePaint.setStyle(Paint.Style.STROKE);
        purplePaint.setStrokeCap(Paint.Cap.ROUND);
        purplePaint.setColor(Ui.PURPLE);

        setContentDescription("ErrJson X");
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float s = Math.min(getWidth(), getHeight());
        float inset = s * 0.03f;
        rect.set(inset, inset, s - inset, s - inset);
        float r = s * 0.26f;

        canvas.drawRoundRect(rect, r, r, bgPaint);
        ringPaint.setStrokeWidth(s * 0.03f);
        canvas.drawRoundRect(rect, r, r, ringPaint);

        float p = s * 0.30f;
        float sw = s * 0.11f;
        purplePaint.setStrokeWidth(sw);
        accentPaint.setStrokeWidth(sw);
        canvas.drawLine(s - p, p, p, s - p, purplePaint);
        canvas.drawLine(p, p, s - p, s - p, accentPaint);
    }
}
