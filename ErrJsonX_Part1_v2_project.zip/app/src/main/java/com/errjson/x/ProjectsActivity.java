package com.errjson.x;

/** Заглушка. Полная версия (создание, редактирование, удаление проектов) будет добавлена в Части 2. */
public class ProjectsActivity extends StubActivity {

    @Override
    protected String screenTitle() {
        return "My Projects";
    }

    @Override
    protected String screenSummary() {
        return "Список ваших проектов. Экран пока не готов.";
    }

    @Override
    protected String[] plannedFeatures() {
        return new String[]{
                "Название, описание и статус проекта",
                "Создание новых записей",
                "Редактирование и удаление",
                "Хранение на устройстве, без интернета"
        };
    }
}
