package com.errjson.x;

/** Заглушка. Полная версия (категории инструментов) будет добавлена в Части 2. */
public class HackToolKitActivity extends StubActivity {

    @Override
    protected String screenTitle() {
        return "HackToolKit";
    }

    @Override
    protected String screenSummary() {
        return "Центр инструментов. Экран пока не готов, но навигация к нему уже работает.";
    }

    @Override
    protected String[] plannedFeatures() {
        return new String[]{
                "Категории инструментов",
                "Запуск встроенных инструментов",
                "Возможность добавлять новые инструменты"
        };
    }
}
