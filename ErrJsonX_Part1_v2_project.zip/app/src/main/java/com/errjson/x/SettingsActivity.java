package com.errjson.x;

import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsActivity extends BaseActivity {

    private static final int[] ACCENTS = {
            0xFF00E5FF, 0xFFA855F7, 0xFF22C55E, 0xFFFB923C, 0xFFF472B6
    };
    private static final String[] ACCENT_NAMES = {
            "Голубой", "Фиолетовый", "Зелёный", "Оранжевый", "Розовый"
    };

    /** SeekBar 0..45 соответствует масштабу текста 85%..130%. */
    private static final int SCALE_STEPS = 45;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout content = setPage("Settings");

        content.addView(buildAccentCard());
        content.addView(Ui.spacer(this, 12));
        content.addView(buildTextSizeCard());
        content.addView(Ui.spacer(this, 12));
        content.addView(buildAnimationCard());
        content.addView(Ui.spacer(this, 12));
        content.addView(buildInfoCard());
        content.addView(Ui.spacer(this, 12));

        TextView reset = Ui.button(this, "Сбросить настройки", Ui.PURPLE, false);
        reset.setOnClickListener(v -> {
            Prefs.reset(this);
            toast("Настройки сброшены");
            recreate();
        });
        content.addView(reset, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private View buildAccentCard() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.sectionLabel(this, "Акцентный цвет"));
        card.addView(Ui.spacer(this, 12));

        int current = Prefs.getAccent(this);
        String currentName = "Свой";

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < ACCENTS.length; i++) {
            final int color = ACCENTS[i];
            if (color == current) {
                currentName = ACCENT_NAMES[i];
            }
            View swatch = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(color);
            if (color == current) {
                g.setStroke(dp(3), Ui.TEXT);
            }
            swatch.setBackground(g);
            swatch.setContentDescription(ACCENT_NAMES[i]);
            swatch.setClickable(true);
            swatch.setFocusable(true);
            swatch.setOnClickListener(v -> {
                Prefs.setAccent(this, color);
                recreate();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(40));
            if (i < ACCENTS.length - 1) {
                lp.rightMargin = dp(12);
            }
            row.addView(swatch, lp);
        }
        card.addView(row);
        card.addView(Ui.spacer(this, 10));
        card.addView(Ui.text(this, "Сейчас: " + currentName, 12, Ui.MUTED, false));
        return card;
    }

    private View buildTextSizeCard() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.sectionLabel(this, "Размер текста"));
        card.addView(Ui.spacer(this, 12));

        float scale = Prefs.getTextScale(this);
        final TextView value = Ui.mono(this, Math.round(scale * 100) + "%", 13,
                Prefs.getAccent(this), true);
        final TextView preview = Ui.text(this, "Ломаем рамки. Создаём возможности.", 15, Ui.TEXT, false);

        card.addView(value);
        card.addView(Ui.spacer(this, 8));

        SeekBar bar = new SeekBar(this);
        bar.setMax(SCALE_STEPS);
        bar.setProgress(Math.round((scale - Prefs.MIN_SCALE) * 100f));
        ColorStateList tint = ColorStateList.valueOf(Prefs.getAccent(this));
        bar.setProgressTintList(tint);
        bar.setThumbTintList(tint);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float sc = Prefs.MIN_SCALE + progress / 100f;
                value.setText(Math.round(sc * 100) + "%");
                preview.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15 * sc);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Prefs.setTextScale(SettingsActivity.this,
                        Prefs.MIN_SCALE + seekBar.getProgress() / 100f);
                recreate();
            }
        });
        card.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        card.addView(Ui.spacer(this, 8));
        card.addView(preview);
        return card;
    }

    private View buildAnimationCard() {
        LinearLayout card = Ui.card(this);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(Ui.text(this, "Анимации", 16, Ui.TEXT, true));
        labels.addView(Ui.text(this, "Появление карточек и эффект нажатия", 12, Ui.MUTED, false));
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        int accent = Prefs.getAccent(this);
        int[][] states = {
                {android.R.attr.state_checked},
                {-android.R.attr.state_checked}
        };
        Switch sw = new Switch(this);
        sw.setChecked(Prefs.animationsEnabled(this));
        sw.setThumbTintList(new ColorStateList(states, new int[]{accent, Ui.MUTED}));
        sw.setTrackTintList(new ColorStateList(states,
                new int[]{Ui.withAlpha(accent, 0x66), 0xFF2A2A40}));
        sw.setOnCheckedChangeListener((button, checked) -> {
            Prefs.setAnimations(this, checked);
            recreate();
        });
        row.addView(sw, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        card.addView(row);
        return card;
    }

    private View buildInfoCard() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.sectionLabel(this, "Информация"));
        card.addView(Ui.spacer(this, 8));
        card.addView(Ui.infoRow(this, "APP", "ErrJson X"));
        card.addView(Ui.infoRow(this, "VERSION",
                BuildConfig.VERSION_NAME + " (build " + BuildConfig.VERSION_CODE + ")"));
        card.addView(Ui.infoRow(this, "PACKAGE", getPackageName()));
        card.addView(Ui.infoRow(this, "ANDROID",
                Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"));
        card.addView(Ui.infoRow(this, "AUTHOR", "ErrJsonMODS"));
        return card;
    }
}
