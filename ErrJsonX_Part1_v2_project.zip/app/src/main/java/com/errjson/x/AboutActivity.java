package com.errjson.x;

import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AboutActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout content = setPage("About");

        LinearLayout hero = Ui.card(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.addView(new LogoView(this), new LinearLayout.LayoutParams(dp(84), dp(84)));
        hero.addView(Ui.spacer(this, 14));

        TextView name = Ui.text(this, "ErrJson X", 28, Ui.TEXT, true);
        name.setGravity(Gravity.CENTER);
        hero.addView(name);
        hero.addView(Ui.spacer(this, 4));

        TextView sub = Ui.mono(this, "TOOLS • MODS • CODE • PROJECTS", 12, Ui.PURPLE, true);
        sub.setLetterSpacing(0.08f);
        sub.setGravity(Gravity.CENTER);
        hero.addView(sub);
        hero.addView(Ui.spacer(this, 4));

        TextView by = Ui.mono(this, "BY ErrJsonMODS", 11, Ui.MUTED, false);
        by.setGravity(Gravity.CENTER);
        hero.addView(by);
        hero.addView(Ui.spacer(this, 12));

        TextView slogan = Ui.text(this, "«Ломаем рамки. Создаём возможности.»", 14, Prefs.getAccent(this), false);
        slogan.setGravity(Gravity.CENTER);
        hero.addView(slogan);

        Ui.fadeIn(hero, 0);
        content.addView(hero, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(Ui.spacer(this, 12));

        LinearLayout info = Ui.card(this);
        info.addView(Ui.sectionLabel(this, "Сведения"));
        info.addView(Ui.spacer(this, 8));
        info.addView(Ui.infoRow(this, "APP", "ErrJson X"));
        info.addView(Ui.infoRow(this, "AUTHOR", "ErrJsonMODS"));
        info.addView(Ui.infoRow(this, "VERSION",
                BuildConfig.VERSION_NAME + " (build " + BuildConfig.VERSION_CODE + ")"));
        info.addView(Ui.infoRow(this, "BUILD", BuildConfig.DEBUG ? "debug" : "release"));
        info.addView(Ui.infoRow(this, "PACKAGE", getPackageName()));
        Ui.fadeIn(info, 80);
        content.addView(info, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(Ui.spacer(this, 12));

        LinearLayout note = Ui.card(this);
        note.addView(Ui.sectionLabel(this, "Приватность"));
        note.addView(Ui.spacer(this, 8));
        note.addView(Ui.text(this,
                "Приложение работает без интернета и не запрашивает разрешений. "
                        + "Файлы выбираются через системный диалог Android.",
                13, Ui.MUTED, false));
        Ui.fadeIn(note, 160);
        content.addView(note, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }
}
