package com.errjson.x;

/** Заглушка. Полная версия (работа с файлами через системный диалог) будет добавлена в Части 3. */
public class FileManagerActivity extends StubActivity {

    @Override
    protected String screenTitle() {
        return "File Manager";
    }

    @Override
    protected String screenSummary() {
        return "Работа с файлами пользователя. Экран пока не готов.";
    }

    @Override
    protected String[] plannedFeatures() {
        return new String[]{
                "Выбор файлов через системный диалог Android",
                "Сведения о файле: имя, размер, тип",
                "Сохранение копии файла",
                "Без запроса лишних разрешений"
        };
    }
}
