package com.errjson.x;

/** Заглушка. Базовая версия (сведения об APK и копия файла) будет добавлена в Части 4. */
public class ApkToolkitActivity extends StubActivity {

    @Override
    protected String screenTitle() {
        return "APK Toolkit";
    }

    @Override
    protected String screenSummary() {
        return "Просмотр сведений об APK-файлах, на изменение которых у вас есть право. "
                + "Экран пока не готов. Изменение, пересборка и переподпись APK не планируются.";
    }

    @Override
    protected String[] plannedFeatures() {
        return new String[]{
                "Выбор APK через системный диалог",
                "Имя файла, размер, пакет, версия",
                "Минимальная версия Android и разрешения из манифеста",
                "Сохранение копии выбранного файла"
        };
    }
}
