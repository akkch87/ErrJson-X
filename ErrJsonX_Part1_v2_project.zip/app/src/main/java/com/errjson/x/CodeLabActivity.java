package com.errjson.x;

/** Заглушка. Полная версия (редактор кода) будет добавлена в Части 3. */
public class CodeLabActivity extends StubActivity {

    @Override
    protected String screenTitle() {
        return "Code Lab";
    }

    @Override
    protected String screenSummary() {
        return "Редактор текста и исходного кода. Экран пока не готов. "
                + "Выполнение кода в приложении не планируется: это редактор и просмотр.";
    }

    @Override
    protected String[] plannedFeatures() {
        return new String[]{
                "Ввод и редактирование кода",
                "Очистка поля и копирование текста",
                "Сохранение в файл и открытие текстовых файлов",
                "Выбор языка подсветки"
        };
    }
}
