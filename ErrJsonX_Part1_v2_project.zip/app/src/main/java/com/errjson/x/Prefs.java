package com.errjson.x;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки интерфейса. Данные пользователя (проекты, код) хранятся отдельно. */
public final class Prefs {

    private static final String FILE = "errjson_ui_prefs";
    private static final String K_ACCENT = "accent";
    private static final String K_TEXT_SCALE = "text_scale";
    private static final String K_ANIM = "animations";
    private static final String K_STAMP = "stamp";

    public static final int DEFAULT_ACCENT = 0xFF00E5FF;
    public static final float MIN_SCALE = 0.85f;
    public static final float MAX_SCALE = 1.30f;

    private Prefs() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static int getAccent(Context c) {
        return sp(c).getInt(K_ACCENT, DEFAULT_ACCENT);
    }

    public static void setAccent(Context c, int color) {
        SharedPreferences p = sp(c);
        p.edit().putInt(K_ACCENT, color).putLong(K_STAMP, p.getLong(K_STAMP, 0) + 1).apply();
    }

    public static float getTextScale(Context c) {
        float v = sp(c).getFloat(K_TEXT_SCALE, 1.0f);
        return Math.max(MIN_SCALE, Math.min(MAX_SCALE, v));
    }

    public static void setTextScale(Context c, float scale) {
        float v = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale));
        SharedPreferences p = sp(c);
        p.edit().putFloat(K_TEXT_SCALE, v).putLong(K_STAMP, p.getLong(K_STAMP, 0) + 1).apply();
    }

    public static boolean animationsEnabled(Context c) {
        return sp(c).getBoolean(K_ANIM, true);
    }

    public static void setAnimations(Context c, boolean enabled) {
        SharedPreferences p = sp(c);
        p.edit().putBoolean(K_ANIM, enabled).putLong(K_STAMP, p.getLong(K_STAMP, 0) + 1).apply();
    }

    /** Меняется при каждой смене настроек. Экраны сравнивают его и пересоздаются. */
    public static long getStamp(Context c) {
        return sp(c).getLong(K_STAMP, 0);
    }

    public static void reset(Context c) {
        SharedPreferences p = sp(c);
        p.edit()
                .remove(K_ACCENT)
                .remove(K_TEXT_SCALE)
                .remove(K_ANIM)
                .putLong(K_STAMP, p.getLong(K_STAMP, 0) + 1)
                .apply();
    }
}
