package com.errjson.x;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

/**
 * Общий каркас экранов. Кнопка «Назад» работает штатно (закрывает экран).
 * При смене настроек внешнего вида экран сам пересоздаётся в onResume.
 */
public abstract class BaseActivity extends Activity {

    private long appliedStamp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appliedStamp = Prefs.getStamp(this);
        getWindow().setBackgroundDrawable(new ColorDrawable(Ui.BG));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Prefs.getStamp(this) != appliedStamp) {
            recreate();
        }
    }

    protected int dp(float v) {
        return Ui.dp(this, v);
    }

    protected void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    protected void toastLong(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    protected void copyText(String label, String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null) {
                toast("Буфер обмена недоступен");
                return;
            }
            cm.setPrimaryClip(ClipData.newPlainText(label, text));
            toast("Скопировано");
        } catch (RuntimeException e) {
            toast("Не удалось скопировать: " + e.getMessage());
        }
    }

    // ---------- Построение экранов ----------

    private LinearLayout newOuter() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(Ui.BG);
        outer.setPadding(dp(16), dp(12), dp(16), 0);
        return outer;
    }

    private LinearLayout buildScroll(LinearLayout parent, int maxWidthDp) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        int avail = getResources().getDisplayMetrics().widthPixels - dp(32);
        int width = Math.min(dp(maxWidthDp), avail);
        sv.addView(content, new FrameLayout.LayoutParams(
                width, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL));

        parent.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return content;
    }

    /** Экран без верхней панели, с прокруткой. Для главного экрана. */
    protected LinearLayout setHomeScroll(int maxWidthDp) {
        LinearLayout outer = newOuter();
        LinearLayout content = buildScroll(outer, maxWidthDp);
        content.setPadding(0, dp(12), 0, dp(24));
        setContentView(outer);
        return content;
    }

    /** Экран с верхней панелью и прокручиваемым содержимым. Возвращает контейнер содержимого. */
    protected LinearLayout setPage(String title) {
        LinearLayout outer = newOuter();
        outer.addView(Ui.topBar(this, title), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout content = buildScroll(outer, 720);
        content.setPadding(0, dp(16), 0, dp(24));
        setContentView(outer);
        return content;
    }

    /** Экран с верхней панелью без прокрутки (для редакторов). Возвращает контейнер содержимого. */
    protected LinearLayout setPageFixed(String title) {
        LinearLayout outer = newOuter();
        outer.addView(Ui.topBar(this, title), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(12), 0, dp(16));
        outer.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(outer);
        return content;
    }
}
