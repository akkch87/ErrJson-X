package com.errjson.x;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StatFs;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends BaseActivity {

    private static final class Section {
        final String icon;
        final String title;
        final String desc;
        final Class<? extends Activity> cls;

        Section(String icon, String title, String desc, Class<? extends Activity> cls) {
            this.icon = icon;
            this.title = title;
            this.desc = desc;
            this.cls = cls;
        }
    }

    private static final Section[] SECTIONS = {
            new Section(">_", "HackToolKit", "Центр инструментов", HackToolKitActivity.class),
            new Section("{ }", "My Projects", "Список проектов", ProjectsActivity.class),
            new Section("</>", "Code Lab", "Редактор и просмотр кода", CodeLabActivity.class),
            new Section("[=]", "File Manager", "Работа с файлами", FileManagerActivity.class),
            new Section("(*)", "Settings", "Цвет, текст, анимации", SettingsActivity.class),
            new Section("(i)", "About", "О приложении и авторе", AboutActivity.class),
    };

    private static final Section APK_SECTION = new Section(
            "APK", "APK Toolkit", "Сведения о пакете и копия файла", ApkToolkitActivity.class);

    private LogoView logo;
    private ObjectAnimator pulse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int accent = Prefs.getAccent(this);

        LinearLayout content = setHomeScroll(900);

        View header = buildHeader(accent);
        content.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Ui.fadeIn(header, 0);

        content.addView(Ui.spacer(this, 24));
        content.addView(Ui.sectionLabel(this, "Разделы"));
        content.addView(Ui.spacer(this, 12));

        int cols = columns();
        for (int i = 0; i < SECTIONS.length; i += cols) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < cols; j++) {
                int idx = i + j;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
                if (j > 0) {
                    lp.leftMargin = dp(12);
                }
                if (idx < SECTIONS.length) {
                    View card = buildCard(SECTIONS[idx], idx % 2 == 0 ? accent : Ui.PURPLE, false);
                    Ui.fadeIn(card, 80L + 60L * idx);
                    row.addView(card, lp);
                } else {
                    row.addView(new View(this), lp);
                }
            }
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = dp(12);
            content.addView(row, rlp);
        }

        View apkCard = buildCard(APK_SECTION, Ui.PURPLE, true);
        Ui.fadeIn(apkCard, 80L + 60L * SECTIONS.length);
        content.addView(apkCard, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content.addView(Ui.spacer(this, 24));
        content.addView(Ui.sectionLabel(this, "Статус"));
        content.addView(Ui.spacer(this, 12));
        View status = buildStatus();
        Ui.fadeIn(status, 520);
        content.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content.addView(Ui.spacer(this, 16));
        TextView version = Ui.mono(this,
                "ErrJson X v" + BuildConfig.VERSION_NAME + " • build " + BuildConfig.VERSION_CODE,
                11, Ui.MUTED, false);
        version.setGravity(Gravity.CENTER);
        content.addView(version, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private int columns() {
        int w = getResources().getConfiguration().screenWidthDp;
        if (w >= 840) {
            return 3;
        }
        if (w >= 360) {
            return 2;
        }
        return 1;
    }

    private View buildHeader(int accent) {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setGravity(Gravity.CENTER_HORIZONTAL);

        logo = new LogoView(this);
        h.addView(logo, new LinearLayout.LayoutParams(dp(84), dp(84)));
        h.addView(Ui.spacer(this, 14));

        SpannableString title = new SpannableString("ErrJson X");
        title.setSpan(new ForegroundColorSpan(accent), 8, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView t = Ui.text(this, title, 32, Ui.TEXT, true);
        t.setGravity(Gravity.CENTER);
        h.addView(t);

        h.addView(Ui.spacer(this, 4));
        TextView sub = Ui.mono(this, "TOOLS • MODS • CODE • PROJECTS", 12, Ui.PURPLE, true);
        sub.setLetterSpacing(0.08f);
        sub.setGravity(Gravity.CENTER);
        h.addView(sub);

        h.addView(Ui.spacer(this, 4));
        TextView by = Ui.mono(this, "BY ErrJsonMODS", 11, Ui.MUTED, false);
        by.setGravity(Gravity.CENTER);
        h.addView(by);

        h.addView(Ui.spacer(this, 10));
        TextView slogan = Ui.text(this, "«Ломаем рамки. Создаём возможности.»", 13, Ui.MUTED, false);
        slogan.setGravity(Gravity.CENTER);
        h.addView(slogan);
        return h;
    }

    private View buildCard(final Section s, int color, boolean wide) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        if (wide) {
            card.setGravity(Gravity.CENTER_VERTICAL);
        }
        int p = dp(16);
        card.setPadding(p, p, p, p);
        card.setMinimumHeight(dp(wide ? 72 : 124));
        card.setBackground(Ui.ripple(this, Ui.CARD, 16, Ui.STROKE, 1));
        card.setClickable(true);
        card.setFocusable(true);
        card.setContentDescription(s.title + ". " + s.desc);

        TextView icon = Ui.mono(this, s.icon, 15, color, true);
        icon.setGravity(Gravity.CENTER);
        icon.setPadding(dp(10), dp(6), dp(10), dp(6));
        icon.setBackground(Ui.rounded(this, Ui.withAlpha(color, 0x26), 10, 0, 0));

        TextView title = Ui.text(this, s.title, 16, Ui.TEXT, true);
        TextView desc = Ui.text(this, s.desc, 12, Ui.MUTED, false);

        if (wide) {
            card.addView(icon, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(title);
            col.addView(desc);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.leftMargin = dp(14);
            card.addView(col, clp);
        } else {
            card.addView(icon, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            card.addView(Ui.spacer(this, 14));
            card.addView(title);
            card.addView(Ui.spacer(this, 4));
            card.addView(desc);
        }

        card.setOnClickListener(v -> open(s));
        Ui.pressable(card);
        return card;
    }

    private View buildStatus() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.mono(this, "● SYSTEM READY", 12, Ui.SUCCESS, true));
        card.addView(Ui.spacer(this, 8));
        card.addView(Ui.infoRow(this, "ANDROID",
                Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"));
        card.addView(Ui.infoRow(this, "DEVICE", Build.MANUFACTURER + " " + Build.MODEL));
        card.addView(Ui.infoRow(this, "FREE", freeSpace()));
        card.addView(Ui.infoRow(this, "ANIMATIONS",
                Prefs.animationsEnabled(this) ? "ON" : "OFF"));
        return card;
    }

    private String freeSpace() {
        try {
            StatFs fs = new StatFs(getFilesDir().getAbsolutePath());
            return Ui.formatSize(fs.getAvailableBytes());
        } catch (RuntimeException e) {
            return "—";
        }
    }

    /** Открывает раздел. Класс экрана проверяется компилятором, ошибка запуска не роняет приложение. */
    private void open(Section s) {
        try {
            startActivity(new Intent(this, s.cls));
        } catch (RuntimeException e) {
            toast("Не удалось открыть раздел: " + e.getMessage());
        }
    }

    // ---------- Анимация логотипа ----------

    private void startPulse() {
        if (logo == null || !Prefs.animationsEnabled(this)) {
            return;
        }
        stopPulse();
        pulse = ObjectAnimator.ofPropertyValuesHolder(logo,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.05f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.05f));
        pulse.setDuration(2200);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.start();
    }

    private void stopPulse() {
        if (pulse != null) {
            pulse.cancel();
            pulse = null;
        }
        if (logo != null) {
            logo.setScaleX(1f);
            logo.setScaleY(1f);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startPulse();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopPulse();
    }

    @Override
    protected void onDestroy() {
        stopPulse();
        super.onDestroy();
    }
}
