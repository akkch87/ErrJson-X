package com.errjson.x;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Основа для экранов, которые ещё не реализованы. Честно показывает, что раздел в разработке
 * и что в нём появится. Кнопка «На главный экран» рабочая. Когда экран будет реализован,
 * его файл заменяется, а наследование от этого класса убирается.
 */
public abstract class StubActivity extends BaseActivity {

    protected abstract String screenTitle();

    protected abstract String screenSummary();

    protected abstract String[] plannedFeatures();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout content = setPage(screenTitle());

        LinearLayout card = Ui.card(this);
        card.addView(Ui.mono(this, "● В РАЗРАБОТКЕ", 12, Ui.PURPLE, true));
        card.addView(Ui.spacer(this, 10));
        card.addView(Ui.text(this, screenSummary(), 15, Ui.TEXT, false));
        card.addView(Ui.spacer(this, 16));
        card.addView(Ui.sectionLabel(this, "Что появится"));
        card.addView(Ui.spacer(this, 8));
        for (String feature : plannedFeatures()) {
            card.addView(Ui.text(this, "•  " + feature, 13, Ui.MUTED, false));
            card.addView(Ui.spacer(this, 4));
        }
        Ui.fadeIn(card, 0);
        content.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content.addView(Ui.spacer(this, 16));
        TextView back = Ui.button(this, "На главный экран", Prefs.getAccent(this), true);
        back.setOnClickListener(v -> finish());
        content.addView(back, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }
}
